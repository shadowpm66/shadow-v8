from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Zone:
    name: str
    price: float
    band: float
    strength: float = 1.0

    def contains(self, price: float) -> bool:
        return abs(price - self.price) <= self.band


def nearest_zone(price: float, zones: list[Zone]) -> Zone | None:
    if not zones:
        return None
    return min(zones, key=lambda z: abs(price - z.price))

