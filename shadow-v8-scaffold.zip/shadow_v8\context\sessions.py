from __future__ import annotations

from datetime import datetime, timezone


def session_label(now: datetime | None = None) -> str:
    now = now or datetime.now(timezone.utc)
    hour = now.hour
    if 0 <= hour < 7:
        return "Asia"
    if 7 <= hour < 12:
        return "London"
    if 12 <= hour < 20:
        return "NY"
    return "Late NY"

