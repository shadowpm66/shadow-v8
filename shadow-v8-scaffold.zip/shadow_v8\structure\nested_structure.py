from __future__ import annotations

from shadow_v8.models import Candle, NestedStructureState
from shadow_v8.structure.wm_detector import WmDetector
from shadow_v8.utils import clamp


class NestedStructureDetector:
    def __init__(self) -> None:
        self.detector = WmDetector()

    def detect(self, candles: list[Candle]) -> NestedStructureState:
        if len(candles) < 60:
            return NestedStructureState(pattern="NONE", reasons=["Need more candles for nested structure"])
        outer = self.detector.detect(candles[-90:])
        inner = self.detector.detect(candles[-35:])
        if outer.type == "W" and inner.type == "W":
            pattern = "W_WITHIN_W"
        elif outer.type == "M" and inner.type == "M":
            pattern = "M_WITHIN_M"
        elif outer.type != "NONE" and inner.type != "NONE":
            pattern = "MIXED"
        else:
            pattern = "NONE"
        confirmed = pattern in ("W_WITHIN_W", "M_WITHIN_M")
        score = clamp((outer.quality_score + inner.quality_score) / 2.0, 0.0, 100.0) if confirmed else 0.0
        return NestedStructureState(
            pattern=pattern,
            confirmed=confirmed,
            outer_structure=outer if outer.type != "NONE" else None,
            inner_structure=inner if inner.type != "NONE" else None,
            quality_score=score,
            reasons=[f"Nested pattern: {pattern}"],
        )

