# Shadow v8 AWS Deployment

This keeps the same EC2 style as the current Shadow bot: one Python app, `.env`
credentials, logs on disk, and optional broker services.

## 1. Upload Code

From your local machine:

```bash
scp -r shadow_v8 requirements.txt .env.example ubuntu@YOUR_EC2_IP:~/shadow-v8/
```

If the folder does not exist yet:

```bash
ssh ubuntu@YOUR_EC2_IP
mkdir -p ~/shadow-v8
exit
```

Then re-run the `scp` command.

## 2. Create Python Environment

On EC2:

```bash
cd ~/shadow-v8
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

## 3. Create `.env`

```bash
cp .env.example .env
nano .env
```

Start safely:

```text
CRYPTO_LIVE_TRADING_ENABLED=true
STOCK_LIVE_TRADING_ENABLED=false
IBKR_ENABLED=false
```

Only enable IBKR after IB Gateway / paper trading is stable.

## 4. Smoke Test

```bash
source venv/bin/activate
python -m shadow_v8.main
```

Expected output includes:

```text
Shadow v8 foundation loaded.
Enabled assets: ['ETHUSDT']
Stock scanner enabled: True
```

## 5. Run With systemd

Create service:

```bash
sudo nano /etc/systemd/system/shadow-v8.service
```

Paste:

```ini
[Unit]
Description=Shadow v8 Trading Engine
After=network-online.target
Wants=network-online.target

[Service]
WorkingDirectory=/home/ubuntu/shadow-v8
ExecStart=/home/ubuntu/shadow-v8/venv/bin/python -m shadow_v8.main
Restart=always
RestartSec=10
User=ubuntu
Environment=PYTHONUNBUFFERED=1

[Install]
WantedBy=multi-user.target
```

Enable and start:

```bash
sudo systemctl daemon-reload
sudo systemctl enable shadow-v8
sudo systemctl start shadow-v8
sudo systemctl status shadow-v8
```

View logs:

```bash
journalctl -u shadow-v8 -f
```

## 6. IBKR Note

Bybit crypto can run like the current bot. Direct stock execution needs IB Gateway
or TWS running on the server or reachable from the server.

Recommended first stock mode:

```text
Stocks: scan + Telegram alerts
IBKR execution: disabled
```

Then later:

```text
IBKR paper trading
IBKR live trading
```

