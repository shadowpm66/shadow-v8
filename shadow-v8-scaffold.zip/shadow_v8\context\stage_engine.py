from __future__ import annotations

from shadow_v8.models import Candle, Stage, StageState
from shadow_v8.structure.indicators import closes, sma


class StageEngine:
    def evaluate(self, weekly: list[Candle], daily: list[Candle] | None = None) -> StageState:
        weekly_stage = self._stage_for(weekly, period=30)
        daily_stage = self._stage_for(daily or [], period=50)
        long_permission = weekly_stage == Stage.STAGE_2 and daily_stage in (Stage.STAGE_2, Stage.UNKNOWN)
        short_permission = weekly_stage == Stage.STAGE_4
        risk_bias = "RISK_ON" if long_permission else ("DEFENSIVE" if short_permission else "NEUTRAL")
        return StageState(
            weekly_stage=weekly_stage,
            daily_stage=daily_stage,
            long_permission=long_permission,
            short_permission=short_permission,
            risk_bias=risk_bias,
            reasons=[
                f"Weekly {weekly_stage.value}",
                f"Daily {daily_stage.value}",
                "Long permission" if long_permission else "No long permission",
                "Short permission" if short_permission else "No short permission",
            ],
        )

    def _stage_for(self, candles: list[Candle], period: int) -> Stage:
        if len(candles) < period + 5:
            return Stage.UNKNOWN
        values = closes(candles)
        ma_now = sma(values, period)
        ma_prev = sum(values[-period - 5 : -5]) / period
        price = values[-1]
        if ma_now is None:
            return Stage.UNKNOWN
        slope_up = ma_now > ma_prev
        if price > ma_now and slope_up:
            return Stage.STAGE_2
        if price < ma_now and not slope_up:
            return Stage.STAGE_4
        if price > ma_now and not slope_up:
            return Stage.STAGE_3
        return Stage.STAGE_1

