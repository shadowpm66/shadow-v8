from __future__ import annotations

from shadow_v8.models import (
    BaseState,
    EarningsState,
    FundamentalState,
    NestedStructureState,
    PivotConfirmation,
    SetupDecision,
    Stage,
    StageState,
    StructureSignal,
    VcpState,
)
from shadow_v8.utils import clamp


class Scorer:
    def score(
        self,
        symbol: str,
        stage: StageState,
        base: BaseState,
        vcp: VcpState,
        structure: StructureSignal,
        nested: NestedStructureState,
        pivot: PivotConfirmation,
        fundamentals: FundamentalState | None = None,
        earnings: EarningsState | None = None,
    ) -> SetupDecision:
        reasons: list[str] = []
        technical = 0.0
        if stage.weekly_stage == Stage.STAGE_2 and structure.direction == "LONG":
            technical += 18
            reasons.append("Weekly Stage 2")
        if stage.weekly_stage == Stage.STAGE_4 and structure.direction == "SHORT":
            technical += 18
            reasons.append("Weekly Stage 4")
        if base.found:
            technical += base.quality_score * 0.20
            reasons.extend(base.reasons[:2])
        if vcp.is_tight:
            technical += vcp.tightness_score * 0.18
            reasons.append("VCP tight")
        if structure.type != "NONE":
            technical += structure.quality_score * 0.20
            reasons.append(f"{structure.type} structure")
        if nested.confirmed:
            technical += nested.quality_score * 0.12
            reasons.append(nested.pattern)
        if pivot.confirmed:
            technical += 18
            reasons.append("Pivot retest and shift-away confirmed")
        elif pivot.retest_hold:
            technical += 10
            reasons.append("Pivot retest held")

        fundamental_score = 0.0
        if fundamentals:
            if fundamentals.revenue_accelerating:
                fundamental_score += 35
                reasons.append("Revenue accelerating")
            if fundamentals.eps_accelerating:
                fundamental_score += 35
                reasons.append("EPS accelerating")
            if fundamentals.fcf_positive:
                fundamental_score += 10
            if fundamentals.gross_margin_expanding or fundamentals.operating_margin_expanding:
                fundamental_score += 10
        if earnings and earnings.blocked_for_earnings:
            reasons.append("Upcoming earnings block")

        technical = clamp(technical, 0, 100)
        fundamental_score = clamp(fundamental_score, 0, 100)
        if fundamentals:
            final = technical * 0.65 + fundamental_score * 0.35
        else:
            final = technical
        if earnings and earnings.blocked_for_earnings:
            final = min(final, 50)

        grade = "REJECT"
        if final >= 90:
            grade = "S"
        elif final >= 85:
            grade = "A+"
        elif final >= 75:
            grade = "A"
        elif final >= 65:
            grade = "B"
        elif final >= 55:
            grade = "C"

        setup_class = self._setup_class(stage, vcp, structure, nested, pivot, fundamentals)
        return SetupDecision(
            symbol=symbol,
            direction=structure.direction,
            setup_class=setup_class,
            grade=grade,
            technical_score=technical,
            fundamental_score=fundamental_score,
            final_score=clamp(final, 0, 100),
            reasons=reasons,
        )

    def _setup_class(
        self,
        stage: StageState,
        vcp: VcpState,
        structure: StructureSignal,
        nested: NestedStructureState,
        pivot: PivotConfirmation,
        fundamentals: FundamentalState | None,
    ) -> str:
        parts: list[str] = []
        parts.append(stage.weekly_stage.value.upper())
        if fundamentals and (fundamentals.revenue_accelerating or fundamentals.eps_accelerating):
            parts.append("ACCELERATION")
        if vcp.is_tight:
            parts.append("VCP")
        if structure.type != "NONE":
            parts.append(structure.type)
        if nested.confirmed:
            parts.append(nested.pattern)
        if pivot.confirmed:
            parts.append("RETEST_SHIFT")
        return "_".join(parts) if parts else "NONE"

