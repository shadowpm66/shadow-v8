from __future__ import annotations

import argparse
import html
import json
import os
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from shadow_v8.config import PATHS


APP_DIR = Path(__file__).resolve().parent
STATIC_DIR = APP_DIR / "static"
DASHBOARD_TOKEN = os.getenv("DASHBOARD_TOKEN", "").strip()

app = FastAPI(title="Shadow v8 Dashboard")
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


def _read_json(path: Path, fallback: Any) -> Any:
    if not path.exists():
        return fallback
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return fallback


def _require_token(request: Request, token: str | None = Query(default=None)) -> None:
    if not DASHBOARD_TOKEN:
        return
    header_token = request.headers.get("X-Shadow-Token")
    if token != DASHBOARD_TOKEN and header_token != DASHBOARD_TOKEN:
        raise HTTPException(status_code=403, detail="Forbidden")


@app.get("/", response_class=HTMLResponse)
def index(request: Request, token: str | None = Query(default=None)) -> HTMLResponse:
    _require_token(request, token)
    scan = _read_json(PATHS["dashboard_scan"], {"generated_at": None, "results": []})
    latest = _read_json(PATHS["dashboard_latest"], {"top": None})
    risk = _read_json(PATHS["dashboard_risk"], {"limits": {}, "positions": [], "scan_risk": []})
    return HTMLResponse(_render_dashboard(scan, latest, risk))


@app.get("/api/scanner")
def scanner_api(request: Request, token: str | None = Query(default=None)) -> JSONResponse:
    _require_token(request, token)
    return JSONResponse(_read_json(PATHS["dashboard_scan"], {"generated_at": None, "results": []}))


@app.get("/api/latest")
def latest_api(request: Request, token: str | None = Query(default=None)) -> JSONResponse:
    _require_token(request, token)
    return JSONResponse(_read_json(PATHS["dashboard_latest"], {"top": None}))


@app.get("/api/risk")
def risk_api(request: Request, token: str | None = Query(default=None)) -> JSONResponse:
    _require_token(request, token)
    return JSONResponse(_read_json(PATHS["dashboard_risk"], {"limits": {}, "positions": [], "scan_risk": []}))


def _render_dashboard(scan: dict[str, Any], latest: dict[str, Any], risk: dict[str, Any]) -> str:
    rows = scan.get("results") or []
    top = latest.get("top") or (rows[0] if rows else None)
    risk_limits = risk.get("limits") or {}
    generated_at = scan.get("generated_at") or "No scan yet"

    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="refresh" content="30">
  <title>Shadow v8 Dashboard</title>
  <link rel="stylesheet" href="/static/style.css">
</head>
<body>
  <header class="topbar">
    <div>
      <h1>Shadow v8</h1>
      <p>Scanner, setup quality, and risk monitor</p>
    </div>
    <div class="updated">
      <span>Last updated</span>
      <strong>{_e(generated_at)}</strong>
    </div>
  </header>

  <main>
    <section class="summary-grid">
      {_top_card(top)}
      {_risk_card(risk_limits)}
      {_status_card(rows)}
    </section>

    <section class="panel">
      <div class="panel-head">
        <h2>Crypto Scanner</h2>
        <span>{len(rows)} symbols</span>
      </div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Rank</th>
              <th>Symbol</th>
              <th>Action</th>
              <th>Grade</th>
              <th>Score</th>
              <th>Weekly</th>
              <th>Daily</th>
              <th>Base</th>
              <th>VCP</th>
              <th>Structure</th>
              <th>Pivot</th>
              <th>Risk</th>
              <th>Reason</th>
            </tr>
          </thead>
          <tbody>
            {''.join(_scanner_row(row) for row in rows)}
          </tbody>
        </table>
      </div>
    </section>
  </main>
</body>
</html>"""


def _top_card(top: dict[str, Any] | None) -> str:
    if not top:
        return '<section class="card"><h2>Top Setup</h2><p class="muted">No scan data yet.</p></section>'
    return f"""
      <section class="card">
        <h2>Top Setup</h2>
        <div class="metric-row">
          <strong>{_e(top.get("symbol"))}</strong>
          <span class="badge {_class_for_action(top.get("action"))}">{_e(top.get("action"))}</span>
        </div>
        <div class="score">{_e(top.get("score"))}</div>
        <p>{_e(top.get("entry_reason"))}</p>
      </section>
    """


def _risk_card(limits: dict[str, Any]) -> str:
    return f"""
      <section class="card">
        <h2>Risk Limits</h2>
        <dl class="kv">
          <dt>Total positions</dt><dd>{_e(limits.get("max_open_positions_total", "-"))}</dd>
          <dt>Crypto positions</dt><dd>{_e(limits.get("max_open_crypto_positions", "-"))}</dd>
          <dt>Daily R limit</dt><dd>{_e(limits.get("daily_r_limit", "-"))}</dd>
        </dl>
      </section>
    """


def _status_card(rows: list[dict[str, Any]]) -> str:
    enter = sum(1 for row in rows if row.get("action") == "ENTER")
    monitor = sum(1 for row in rows if row.get("action") == "MONITOR")
    skip = sum(1 for row in rows if row.get("action") == "SKIP")
    return f"""
      <section class="card">
        <h2>Actions</h2>
        <div class="mini-stats">
          <span><strong>{enter}</strong> Enter</span>
          <span><strong>{monitor}</strong> Monitor</span>
          <span><strong>{skip}</strong> Skip</span>
        </div>
      </section>
    """


def _scanner_row(row: dict[str, Any]) -> str:
    reason = row.get("entry_reason") or "; ".join(row.get("reasons") or [])
    return f"""
      <tr>
        <td>{_e(row.get("rank"))}</td>
        <td><strong>{_e(row.get("symbol"))}</strong><span class="sub">{_e(row.get("last_price"))}</span></td>
        <td><span class="badge {_class_for_action(row.get("action"))}">{_e(row.get("action"))}</span></td>
        <td>{_e(row.get("grade"))}</td>
        <td>{_e(row.get("score"))}</td>
        <td>{_e(row.get("weekly_stage"))}</td>
        <td>{_e(row.get("daily_stage"))}</td>
        <td>{_e(row.get("base_quality"))}</td>
        <td>{_e(row.get("vcp_score"))}</td>
        <td>{_e(row.get("structure_type"))}/{_e(row.get("structure_score"))}</td>
        <td>{_yes_no(row.get("pivot_confirmed"))}</td>
        <td>{_e(row.get("risk_state"))}</td>
        <td class="reason">{_e(reason)}</td>
      </tr>
    """


def _class_for_action(action: Any) -> str:
    action_text = str(action or "").lower()
    if action_text == "enter":
        return "good"
    if action_text == "monitor":
        return "watch"
    if action_text == "wait":
        return "wait"
    return "skip"


def _yes_no(value: Any) -> str:
    return "Yes" if value else "No"


def _e(value: Any) -> str:
    if value is None:
        return "-"
    return html.escape(str(value))


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the Shadow v8 dashboard")
    parser.add_argument("--host", default=os.getenv("DASHBOARD_HOST", "127.0.0.1"))
    parser.add_argument("--port", type=int, default=int(os.getenv("DASHBOARD_PORT", "8501")))
    args = parser.parse_args()

    import uvicorn

    uvicorn.run("shadow_v8.dashboard.app:app", host=args.host, port=args.port, reload=False)


if __name__ == "__main__":
    main()
