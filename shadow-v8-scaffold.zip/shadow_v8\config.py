from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv

from shadow_v8.models import AssetConfig, BrokerConfig, ScannerConfig


ROOT_DIR = Path(__file__).resolve().parent.parent
load_dotenv(ROOT_DIR / ".env")


PATHS = {
    "state": ROOT_DIR / "runtime" / "state.json",
    "positions": ROOT_DIR / "runtime" / "positions.json",
    "logs": ROOT_DIR / "logs",
    "daily_logs": ROOT_DIR / "logs" / "daily",
    "research": ROOT_DIR / "logs" / "research.jsonl",
}


BROKERS = {
    "bybit": BrokerConfig(
        name="bybit",
        enabled=os.getenv("BYBIT_ENABLED", "true").lower() in ("1", "true", "on", "yes"),
        paper=os.getenv("BYBIT_PAPER", "false").lower() in ("1", "true", "on", "yes"),
        base_url=os.getenv("BASE_URL", "https://api.bybit.com"),
    ),
    "ibkr": BrokerConfig(
        name="ibkr",
        enabled=os.getenv("IBKR_ENABLED", "false").lower() in ("1", "true", "on", "yes"),
        paper=os.getenv("IBKR_PAPER", "true").lower() in ("1", "true", "on", "yes"),
        account_id=os.getenv("IBKR_ACCOUNT_ID"),
    ),
    "paper": BrokerConfig(name="paper", enabled=True, paper=True),
}


ASSETS = [
    AssetConfig(
        symbol="ETHUSDT",
        asset_class="crypto",
        broker="bybit",
        enabled=True,
        primary_timeframe="15",
        confirmation_timeframe="D",
        intraday_timeframes=("15", "60", "240"),
        allow_long=True,
        allow_short=True,
        fundamentals_required=False,
        max_risk_pct=0.015,
        tags=("default_crypto",),
    ),
    AssetConfig(
        symbol="BTCUSDT",
        asset_class="crypto",
        broker="bybit",
        enabled=os.getenv("BTC_ENABLED", "false").lower() in ("1", "true", "on", "yes"),
        primary_timeframe="15",
        confirmation_timeframe="D",
        intraday_timeframes=("15", "60", "240"),
        allow_long=True,
        allow_short=True,
        fundamentals_required=False,
        max_risk_pct=0.0125,
        tags=("crypto",),
    ),
]


SCANNER_CONFIG = ScannerConfig(
    enabled=True,
    asset_classes=("stock",),
    min_price=float(os.getenv("STOCK_MIN_PRICE", "5")),
    min_avg_dollar_volume=float(os.getenv("STOCK_MIN_AVG_DOLLAR_VOLUME", "20000000")),
    require_fundamentals=True,
    max_results=int(os.getenv("STOCK_SCANNER_MAX_RESULTS", "200")),
)

CRYPTO_SCAN_SYMBOLS = tuple(
    s.strip().upper()
    for s in os.getenv("CRYPTO_SCAN_SYMBOLS", "ETHUSDT,BTCUSDT,SOLUSDT,BNBUSDT,XRPUSDT,LINKUSDT,AVAXUSDT").split(",")
    if s.strip()
)

CRYPTO_SCAN_CONFIG = {
    "enabled": os.getenv("CRYPTO_SCAN_ENABLED", "true").lower() in ("1", "true", "on", "yes"),
    "scan_all_usdt": os.getenv("CRYPTO_SCAN_ALL_USDT", "false").lower() in ("1", "true", "on", "yes"),
    "max_symbols": int(os.getenv("CRYPTO_SCAN_MAX_SYMBOLS", "25")),
    "seed_symbols": CRYPTO_SCAN_SYMBOLS,
}


RISK_CONFIG = {
    "max_open_positions_total": int(os.getenv("MAX_OPEN_POSITIONS_TOTAL", "3")),
    "max_open_crypto_positions": int(os.getenv("MAX_OPEN_CRYPTO_POSITIONS", "1")),
    "max_open_stock_positions": int(os.getenv("MAX_OPEN_STOCK_POSITIONS", "3")),
    "daily_r_limit": float(os.getenv("DAILY_R_LIMIT", "-2.0")),
    "default_stock_risk_pct": float(os.getenv("DEFAULT_STOCK_RISK_PCT", "0.005")),
    "default_crypto_risk_pct": float(os.getenv("DEFAULT_CRYPTO_RISK_PCT", "0.01")),
}


EARNINGS_RULES = {
    "avoid_new_entries_before_days": int(os.getenv("EARNINGS_BLOCK_DAYS", "5")),
    "allow_post_earnings_gap_setups": os.getenv("ALLOW_POST_EARNINGS_SETUPS", "true").lower()
    in ("1", "true", "on", "yes"),
}


FEATURE_FLAGS = {
    "stocks_enabled": os.getenv("STOCKS_ENABLED", "true").lower() in ("1", "true", "on", "yes"),
    "stock_live_trading_enabled": os.getenv("STOCK_LIVE_TRADING_ENABLED", "false").lower()
    in ("1", "true", "on", "yes"),
    "crypto_live_trading_enabled": os.getenv("CRYPTO_LIVE_TRADING_ENABLED", "true").lower()
    in ("1", "true", "on", "yes"),
    "stock_shorts_enabled": os.getenv("STOCK_SHORTS_ENABLED", "false").lower() in ("1", "true", "on", "yes"),
    "research_logging_enabled": True,
}


def enabled_assets() -> list[AssetConfig]:
    return [asset for asset in ASSETS if asset.enabled]


def ensure_runtime_dirs() -> None:
    for key in ("logs", "daily_logs"):
        PATHS[key].mkdir(parents=True, exist_ok=True)
    PATHS["state"].parent.mkdir(parents=True, exist_ok=True)
