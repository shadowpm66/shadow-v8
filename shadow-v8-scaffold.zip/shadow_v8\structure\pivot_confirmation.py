from __future__ import annotations

from shadow_v8.models import Candle, Direction, PivotConfirmation


class PivotConfirmationEngine:
    def evaluate(self, candles: list[Candle], pivot: float | None, direction: Direction) -> PivotConfirmation:
        if pivot is None or len(candles) < 5:
            return PivotConfirmation(pivot=pivot, reasons=["No pivot or not enough candles"])
        recent = candles[-5:]
        last = candles[-1]
        if direction == "LONG":
            reclaimed = any(c.close > pivot for c in recent[:-1])
            retested = any(c.low <= pivot <= c.high for c in recent[-3:])
            retest_hold = retested and last.close > pivot
            shift = retest_hold and last.close > max(c.high for c in recent[:-1])
            strength = ((last.close - pivot) / max(pivot, 1e-9)) * 100.0 if shift else 0.0
        elif direction == "SHORT":
            reclaimed = any(c.close < pivot for c in recent[:-1])
            retested = any(c.low <= pivot <= c.high for c in recent[-3:])
            retest_hold = retested and last.close < pivot
            shift = retest_hold and last.close < min(c.low for c in recent[:-1])
            strength = ((pivot - last.close) / max(pivot, 1e-9)) * 100.0 if shift else 0.0
        else:
            reclaimed = retested = retest_hold = shift = False
            strength = 0.0
        return PivotConfirmation(
            pivot=pivot,
            reclaimed_or_lost=reclaimed,
            retested=retested,
            retest_hold=retest_hold,
            shift_away=shift,
            shift_strength=strength,
            confirmed=reclaimed and retested and retest_hold and shift,
            reasons=[
                "Pivot reclaimed/lost" if reclaimed else "Pivot not reclaimed/lost",
                "Pivot retested" if retested else "Pivot not retested",
                "Retest held" if retest_hold else "Retest did not hold",
                "Shift away confirmed" if shift else "Shift away not confirmed",
            ],
        )

