from __future__ import annotations

from datetime import datetime, timezone

from shadow_v8.config import EARNINGS_RULES
from shadow_v8.models import EarningsState


class EarningsEngine:
    def evaluate(self, next_date: datetime | None) -> EarningsState:
        if next_date is None:
            return EarningsState(reasons=["No earnings date available"])
        now = datetime.now(timezone.utc)
        if next_date.tzinfo is None:
            next_date = next_date.replace(tzinfo=timezone.utc)
        days = (next_date.date() - now.date()).days
        block_days = EARNINGS_RULES["avoid_new_entries_before_days"]
        blocked = 0 <= days <= block_days
        return EarningsState(
            next_earnings_date=next_date,
            days_until_earnings=days,
            blocked_for_earnings=blocked,
            reasons=[f"{days} days until earnings", "Blocked before earnings" if blocked else "No earnings block"],
        )

