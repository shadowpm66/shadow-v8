from __future__ import annotations


class Simulator:
    def run(self) -> dict:
        return {"ok": False, "reason": "Simulator not implemented yet"}

