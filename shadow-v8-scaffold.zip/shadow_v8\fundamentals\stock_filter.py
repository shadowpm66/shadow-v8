from __future__ import annotations

from shadow_v8.models import EarningsState, FundamentalState


class StockFilter:
    def approve(self, fundamentals: FundamentalState, earnings: EarningsState) -> tuple[bool, list[str]]:
        reasons: list[str] = []
        if earnings.blocked_for_earnings:
            return False, ["Upcoming earnings block"]
        if fundamentals.fundamental_grade in ("S", "A", "B"):
            reasons.append(f"Fundamental grade {fundamentals.fundamental_grade}")
            return True, reasons
        return False, [f"Fundamental grade {fundamentals.fundamental_grade} not strong enough"]

