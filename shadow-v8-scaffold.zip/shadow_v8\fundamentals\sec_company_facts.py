from __future__ import annotations


class SecCompanyFactsClient:
    """SEC Company Facts placeholder.

    This will map tickers to CIKs and fetch official XBRL facts in a later phase.
    """

    def get_quarterly_revenue(self, symbol: str) -> list[float]:
        return []

    def get_quarterly_eps(self, symbol: str) -> list[float]:
        return []

