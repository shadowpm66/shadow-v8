from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from shadow_v8.models import AssetConfig, EntryDecision, ExitDecision
from shadow_v8.state_store import PositionStore
from shadow_v8.strategy.position_sizer import size_by_risk


class PaperOrderManager:
    """Paper execution adapter for validating v8 decisions without live orders."""

    def __init__(self, account_balance: float = 10_000.0, store: PositionStore | None = None) -> None:
        self.account_balance = float(account_balance)
        self.store = store or PositionStore()

    def enter(self, asset: AssetConfig, decision: EntryDecision) -> dict[str, Any]:
        if decision.action != "ENTER":
            return {"ok": False, "reason": f"Paper enter ignored action {decision.action}", "symbol": asset.symbol}
        if decision.entry is None or decision.stop is None:
            return {"ok": False, "reason": "Paper enter requires entry and stop", "symbol": asset.symbol}

        entry = float(decision.entry)
        stop = float(decision.stop)
        if not self._valid_stop(decision.direction, entry, stop):
            return {"ok": False, "reason": "Invalid stop side for paper entry", "symbol": asset.symbol}

        positions = self.store.load_all()
        if asset.symbol in positions:
            return {"ok": False, "reason": "Paper position already open", "symbol": asset.symbol}

        risk_pct = float(decision.metadata.get("risk_pct") or asset.max_risk_pct)
        qty = size_by_risk(self.account_balance, risk_pct, entry, stop)
        if qty <= 0:
            return {"ok": False, "reason": "Paper size is zero", "symbol": asset.symbol}

        opened_at = datetime.now(timezone.utc).isoformat()
        risk_dollars = self.account_balance * risk_pct
        initial_risk = abs(entry - stop)
        position = {
            "symbol": asset.symbol,
            "asset_class": asset.asset_class,
            "broker": "paper",
            "source_broker": asset.broker,
            "direction": decision.direction,
            "qty": round(qty, 8),
            "entry": round(entry, 8),
            "stop": round(stop, 8),
            "target": round(float(decision.target), 8) if decision.target is not None else None,
            "opened_at": opened_at,
            "setup_class": decision.setup.setup_class if decision.setup else "",
            "grade": decision.setup.grade if decision.setup else "",
            "setup_score": round(decision.setup.final_score, 2) if decision.setup else None,
            "risk_pct": risk_pct,
            "risk_dollars": round(risk_dollars, 2),
            "initial_risk_per_unit": round(initial_risk, 8),
            "last_price": entry,
            "unrealized_r": 0.0,
            "unrealized_pnl": 0.0,
            "status": "OPEN",
            "metadata": {
                "paper": True,
                "reason": decision.reason,
                "risk_state": decision.metadata.get("risk_state"),
                "risk_reason": decision.metadata.get("risk_reason"),
            },
        }
        positions[asset.symbol] = position
        self.store.save_all(positions)
        return {"ok": True, "reason": "Paper position opened", "symbol": asset.symbol, "position": position}

    def apply_exit(self, asset: AssetConfig, decision: ExitDecision) -> dict[str, Any]:
        positions = self.store.load_all()
        position = positions.get(asset.symbol)
        if not position:
            return {"ok": False, "reason": "No paper position to exit", "symbol": asset.symbol}
        if decision.action not in ("EXIT", "FLATTEN"):
            return {"ok": False, "reason": f"Paper exit ignored action {decision.action}", "symbol": asset.symbol}

        positions.pop(asset.symbol, None)
        self.store.save_all(positions)
        return {"ok": True, "reason": decision.reason, "symbol": asset.symbol, "closed_position": position}

    def mark_to_market(self, prices: dict[str, float]) -> dict[str, Any]:
        positions = self.store.load_all()
        changed = False
        for symbol, position in positions.items():
            if not isinstance(position, dict) or position.get("status") != "OPEN":
                continue
            price = prices.get(symbol)
            if price is None:
                continue
            entry = float(position.get("entry") or 0.0)
            stop = float(position.get("stop") or entry)
            qty = float(position.get("qty") or 0.0)
            direction = position.get("direction")
            risk_per_unit = abs(entry - stop)
            if entry <= 0 or qty <= 0 or risk_per_unit <= 0:
                continue
            open_reward = (price - entry) if direction == "LONG" else (entry - price)
            pnl = open_reward * qty
            position["last_price"] = round(float(price), 8)
            position["unrealized_pnl"] = round(pnl, 2)
            position["unrealized_r"] = round(open_reward / risk_per_unit, 3)
            position["updated_at"] = datetime.now(timezone.utc).isoformat()
            changed = True
        if changed:
            self.store.save_all(positions)
        return {"ok": True, "count": len(positions)}

    def _valid_stop(self, direction: str, entry: float, stop: float) -> bool:
        if direction == "LONG":
            return stop < entry
        if direction == "SHORT":
            return stop > entry
        return False
