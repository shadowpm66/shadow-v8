from __future__ import annotations

from shadow_v8.models import Candle


def average_range(candles: list[Candle], period: int = 20) -> float | None:
    if len(candles) < period:
        return None
    return sum(c.high - c.low for c in candles[-period:]) / period

