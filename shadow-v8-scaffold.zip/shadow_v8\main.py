from __future__ import annotations

from datetime import datetime, timedelta, timezone

from shadow_v8.config import (
    BROKERS,
    CRYPTO_SCAN_CONFIG,
    EARNINGS_RULES,
    FEATURE_FLAGS,
    RISK_CONFIG,
    SCANNER_CONFIG,
    enabled_assets,
    ensure_runtime_dirs,
)
from shadow_v8.context.stage_engine import StageEngine
from shadow_v8.data.bybit_market_data import BybitMarketData
from shadow_v8.data.market_data import CompositeMarketData
from shadow_v8.data.scanner import CryptoScanner
from shadow_v8.fundamentals.earnings_engine import EarningsEngine
from shadow_v8.fundamentals.growth_engine import GrowthEngine
from shadow_v8.fundamentals.stock_filter import StockFilter
from shadow_v8.models import AssetConfig, Candle, MarketDataBundle, ResearchSnapshot
from shadow_v8.strategy.entry_policy import EntryPolicy
from shadow_v8.strategy.risk_manager import RiskManager
from shadow_v8.strategy.scorer import Scorer
from shadow_v8.structure.base_engine import BaseEngine
from shadow_v8.structure.nested_structure import NestedStructureDetector
from shadow_v8.structure.pivot_confirmation import PivotConfirmationEngine
from shadow_v8.structure.vcp_engine import VcpEngine
from shadow_v8.structure.wm_detector import WmDetector
from shadow_v8.telemetry.dashboard_writer import DashboardWriter
from shadow_v8.telemetry.research_logger import ResearchLogger


def _demo_candles(count: int = 120, start: float = 100.0) -> list[Candle]:
    now = datetime.now(timezone.utc)
    candles: list[Candle] = []
    price = start
    for idx in range(count):
        drift = 0.10 if idx > 40 else -0.02
        wave = ((idx % 14) - 7) * 0.06
        open_ = price
        close = max(1.0, price + drift + wave)
        high = max(open_, close) + 0.45
        low = min(open_, close) - 0.45
        volume = 1_000_000 * (0.7 if idx > 95 else 1.0)
        candles.append(
            Candle(
                timestamp=now - timedelta(days=count - idx),
                open=open_,
                high=high,
                low=low,
                close=close,
                volume=volume,
            )
        )
        price = close
    return candles


def main() -> None:
    ensure_runtime_dirs()

    print("Shadow v8 foundation loaded.")
    print(f"Enabled assets: {[asset.symbol for asset in enabled_assets()]}")
    print(f"Stock scanner enabled: {SCANNER_CONFIG.enabled}")
    print(f"Crypto live enabled: {FEATURE_FLAGS['crypto_live_trading_enabled']}")
    print(f"Stock live enabled: {FEATURE_FLAGS['stock_live_trading_enabled']}")
    print(f"IBKR enabled: {BROKERS['ibkr'].enabled}")
    print(f"Earnings block days: {EARNINGS_RULES['avoid_new_entries_before_days']}")
    print(f"Risk config: {RISK_CONFIG}")

    bybit = BybitMarketData()
    scan_assets = CryptoScanner(bybit).scan(CRYPTO_SCAN_CONFIG) or enabled_assets()
    print(f"Crypto scan universe: {[asset.symbol for asset in scan_assets]}")

    scan_results = [_evaluate_asset(asset, bybit) for asset in scan_assets]
    scan_results.sort(key=lambda item: item["setup"].final_score, reverse=True)
    dashboard = DashboardWriter()
    dashboard.write_scan(scan_results)
    dashboard.write_risk(scan_results)

    print("Crypto scan results:")
    for rank, result in enumerate(scan_results, start=1):
        setup = result["setup"]
        stage = result["stage"]
        base = result["base"]
        vcp = result["vcp"]
        structure = result["structure"]
        pivot = result["pivot"]
        entry = result["entry"]
        market = result["market"]
        print(
            f"{rank}. {setup.symbol} action={entry.action} grade={setup.grade} "
            f"score={setup.final_score:.1f} weekly={stage.weekly_stage.value} "
            f"daily={stage.daily_stage.value} base={base.quality_score:.1f} "
            f"vcp={vcp.tightness_score:.1f} structure={structure.type}/{structure.quality_score:.1f} "
            f"pivot={pivot.confirmed} last={market.last_price} source={market.metadata.get('source')}"
        )

    primary = scan_results[0]
    stage = primary["stage"]
    base = primary["base"]
    vcp = primary["vcp"]
    structure = primary["structure"]
    nested = primary["nested"]
    pivot = primary["pivot"]

    fundamentals = GrowthEngine().evaluate(
        revenue=[100, 110, 121, 135, 160, 190, 235, 300],
        eps=[0.20, 0.24, 0.29, 0.35, 0.48, 0.70, 1.05, 1.60],
        gross_margin=[48, 49, 50, 52, 53, 55],
        operating_margin=[12, 13, 15, 17, 19, 22],
        free_cash_flow=[5, 8, 11, 18],
    )
    earnings = EarningsEngine().evaluate(
        next_date=datetime.now(timezone.utc) + timedelta(days=45),
        latest_surprise_pct=12.0,
        latest_report_date=datetime.now(timezone.utc) - timedelta(days=7),
    )
    stock_setup = Scorer().score(
        "DEMO",
        stage,
        base,
        vcp,
        structure,
        nested,
        pivot,
        fundamentals=fundamentals,
        earnings=earnings,
    )
    approved, stock_reasons = StockFilter().approve(fundamentals, earnings, stage, stock_setup)
    print(
        "Dry-run stock filter: "
        f"approved={approved} grade={fundamentals.fundamental_grade} "
        f"setup_grade={stock_setup.grade} reasons={'; '.join(stock_reasons)}"
    )
    print("Dashboard data written: runtime/dashboard/scanner_results.json")
    print("Dashboard data written: runtime/dashboard/latest_snapshot.json")
    print("Dashboard data written: runtime/dashboard/risk_status.json")


def _evaluate_asset(asset: AssetConfig, bybit: BybitMarketData) -> dict:
    market = _load_market_data(asset, bybit)
    daily = market.candles.get("D") or _demo_candles()
    weekly = market.candles.get("W") or _demo_candles(count=80, start=80.0)
    stage = StageEngine().evaluate(weekly=weekly, daily=daily)
    structure = WmDetector().detect(daily)
    base_direction = structure.direction if structure.direction != "FLAT" else "LONG"
    base = BaseEngine().evaluate(daily, direction=base_direction)
    vcp = VcpEngine().evaluate(daily, pivot=base.pivot)
    nested = NestedStructureDetector().detect(daily)
    pivot = PivotConfirmationEngine().evaluate(daily, base.pivot, structure.direction)
    setup = Scorer().score(asset.symbol, stage, base, vcp, structure, nested, pivot)
    risk = RiskManager().evaluate(asset, setup)
    entry = EntryPolicy().decide(asset, setup, risk)

    ResearchLogger().record(
        ResearchSnapshot(
            timestamp=datetime.now(timezone.utc),
            symbol=asset.symbol,
            asset_class=asset.asset_class,
            stage=stage,
            base=base,
            vcp=vcp,
            structure=structure,
            nested_structure=nested,
            pivot_confirmation=pivot,
            setup=setup,
            entry_decision=entry,
            risk_decision=risk,
        )
    )
    return {
        "asset": asset,
        "market": market,
        "stage": stage,
        "base": base,
        "vcp": vcp,
        "structure": structure,
        "nested": nested,
        "pivot": pivot,
        "setup": setup,
        "risk": risk,
        "entry": entry,
    }


def _load_market_data(asset: AssetConfig, bybit: BybitMarketData | None = None) -> MarketDataBundle:
    if asset.broker != "bybit":
        return _demo_market_bundle(asset)
    provider = CompositeMarketData({"bybit": bybit or BybitMarketData()})
    try:
        bundle = provider.load(asset)
        if bundle.candles.get("D") and bundle.candles.get("W"):
            bundle.metadata["source"] = "bybit"
            return bundle
        if not bundle.candles.get("D"):
            bundle.candles["D"] = _demo_candles()
        if not bundle.candles.get("W"):
            bundle.candles["W"] = _demo_candles(count=80, start=80.0)
        bundle.metadata["source"] = "demo_fallback_empty_bybit"
        return bundle
    except Exception as exc:
        bundle = _demo_market_bundle(asset)
        bundle.metadata["source"] = f"demo_fallback_bybit_error:{type(exc).__name__}"
        return bundle


def _demo_market_bundle(asset: AssetConfig) -> MarketDataBundle:
    return MarketDataBundle(
        symbol=asset.symbol,
        asset_class=asset.asset_class,
        candles={"D": _demo_candles(), "W": _demo_candles(count=80, start=80.0)},
        last_price=None,
        metadata={"source": "demo"},
    )


if __name__ == "__main__":
    main()
