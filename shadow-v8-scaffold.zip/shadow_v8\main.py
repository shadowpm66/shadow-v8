from __future__ import annotations

from datetime import datetime, timedelta, timezone

from shadow_v8.config import (
    BROKERS,
    EARNINGS_RULES,
    FEATURE_FLAGS,
    RISK_CONFIG,
    SCANNER_CONFIG,
    enabled_assets,
    ensure_runtime_dirs,
)
from shadow_v8.context.stage_engine import StageEngine
from shadow_v8.models import Candle, ResearchSnapshot
from shadow_v8.strategy.entry_policy import EntryPolicy
from shadow_v8.strategy.risk_manager import RiskManager
from shadow_v8.strategy.scorer import Scorer
from shadow_v8.structure.base_engine import BaseEngine
from shadow_v8.structure.nested_structure import NestedStructureDetector
from shadow_v8.structure.pivot_confirmation import PivotConfirmationEngine
from shadow_v8.structure.vcp_engine import VcpEngine
from shadow_v8.structure.wm_detector import WmDetector
from shadow_v8.telemetry.research_logger import ResearchLogger


def _demo_candles(count: int = 120, start: float = 100.0) -> list[Candle]:
    now = datetime.now(timezone.utc)
    candles: list[Candle] = []
    price = start
    for idx in range(count):
        drift = 0.10 if idx > 40 else -0.02
        wave = ((idx % 14) - 7) * 0.06
        open_ = price
        close = max(1.0, price + drift + wave)
        high = max(open_, close) + 0.45
        low = min(open_, close) - 0.45
        volume = 1_000_000 * (0.7 if idx > 95 else 1.0)
        candles.append(
            Candle(
                timestamp=now - timedelta(days=count - idx),
                open=open_,
                high=high,
                low=low,
                close=close,
                volume=volume,
            )
        )
        price = close
    return candles


def main() -> None:
    ensure_runtime_dirs()

    print("Shadow v8 foundation loaded.")
    print(f"Enabled assets: {[asset.symbol for asset in enabled_assets()]}")
    print(f"Stock scanner enabled: {SCANNER_CONFIG.enabled}")
    print(f"Crypto live enabled: {FEATURE_FLAGS['crypto_live_trading_enabled']}")
    print(f"Stock live enabled: {FEATURE_FLAGS['stock_live_trading_enabled']}")
    print(f"IBKR enabled: {BROKERS['ibkr'].enabled}")
    print(f"Earnings block days: {EARNINGS_RULES['avoid_new_entries_before_days']}")
    print(f"Risk config: {RISK_CONFIG}")

    asset = enabled_assets()[0]
    daily = _demo_candles()
    weekly = _demo_candles(count=80, start=80.0)

    stage = StageEngine().evaluate(weekly=weekly, daily=daily)
    base = BaseEngine().evaluate(daily, direction="LONG")
    vcp = VcpEngine().evaluate(daily, pivot=base.pivot)
    structure = WmDetector().detect(daily)
    nested = NestedStructureDetector().detect(daily)
    pivot = PivotConfirmationEngine().evaluate(daily, base.pivot, structure.direction)
    setup = Scorer().score(asset.symbol, stage, base, vcp, structure, nested, pivot)
    risk = RiskManager().evaluate(asset, setup)
    entry = EntryPolicy().decide(asset, setup, risk)

    ResearchLogger().record(
        ResearchSnapshot(
            timestamp=datetime.now(timezone.utc),
            symbol=asset.symbol,
            asset_class=asset.asset_class,
            stage=stage,
            base=base,
            vcp=vcp,
            structure=structure,
            nested_structure=nested,
            pivot_confirmation=pivot,
            setup=setup,
            entry_decision=entry,
            risk_decision=risk,
        )
    )

    print(f"Dry-run setup: {setup.setup_class} grade={setup.grade} score={setup.final_score:.1f}")
    print(f"Entry decision: {entry.action} - {entry.reason}")


if __name__ == "__main__":
    main()
