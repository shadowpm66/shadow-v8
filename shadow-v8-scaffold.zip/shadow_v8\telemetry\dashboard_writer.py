from __future__ import annotations

import json
from dataclasses import asdict, is_dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from shadow_v8.config import PATHS, RISK_CONFIG, ensure_runtime_dirs


def _json_default(value: Any) -> Any:
    if isinstance(value, datetime):
        return value.isoformat()
    if is_dataclass(value):
        return asdict(value)
    if hasattr(value, "value"):
        return value.value
    return str(value)


class DashboardWriter:
    def write_scan(self, scan_results: list[dict[str, Any]]) -> None:
        rows = [self._scan_row(rank, result) for rank, result in enumerate(scan_results, start=1)]
        self._write_json(
            PATHS["dashboard_scan"],
            {
                "generated_at": datetime.now(timezone.utc).isoformat(),
                "count": len(rows),
                "results": rows,
            },
        )
        if rows:
            self._write_json(PATHS["dashboard_latest"], {"generated_at": datetime.now(timezone.utc).isoformat(), "top": rows[0]})

    def write_risk(self, scan_results: list[dict[str, Any]]) -> None:
        risk_rows = []
        for result in scan_results:
            setup = result["setup"]
            risk = result["risk"]
            risk_rows.append(
                {
                    "symbol": setup.symbol,
                    "direction": setup.direction,
                    "grade": setup.grade,
                    "score": round(setup.final_score, 2),
                    "risk_state": risk.state,
                    "risk_pct": risk.risk_pct,
                    "reason": risk.reason,
                }
            )
        self._write_json(
            PATHS["dashboard_risk"],
            {
                "generated_at": datetime.now(timezone.utc).isoformat(),
                "limits": RISK_CONFIG,
                "positions": [],
                "scan_risk": risk_rows,
            },
        )

    def _scan_row(self, rank: int, result: dict[str, Any]) -> dict[str, Any]:
        setup = result["setup"]
        stage = result["stage"]
        base = result["base"]
        vcp = result["vcp"]
        structure = result["structure"]
        nested = result["nested"]
        pivot = result["pivot"]
        entry = result["entry"]
        risk = result["risk"]
        market = result["market"]
        return {
            "rank": rank,
            "symbol": setup.symbol,
            "asset_class": result["asset"].asset_class,
            "last_price": market.last_price,
            "data_source": market.metadata.get("source"),
            "action": entry.action,
            "entry_reason": entry.reason,
            "direction": setup.direction,
            "setup_class": setup.setup_class,
            "grade": setup.grade,
            "score": round(setup.final_score, 2),
            "technical_score": round(setup.technical_score, 2),
            "weekly_stage": stage.weekly_stage.value,
            "daily_stage": stage.daily_stage.value,
            "risk_bias": stage.risk_bias,
            "base_found": base.found,
            "base_quality": round(base.quality_score, 2),
            "base_depth_pct": round(base.depth_pct, 2) if base.depth_pct is not None else None,
            "vcp_tight": vcp.is_tight,
            "vcp_score": round(vcp.tightness_score, 2),
            "vcp_contractions": vcp.contraction_count,
            "structure_type": structure.type,
            "structure_score": round(structure.quality_score, 2),
            "nested_pattern": nested.pattern,
            "nested_confirmed": nested.confirmed,
            "pivot_confirmed": pivot.confirmed,
            "pivot_retested": pivot.retested,
            "pivot_shift_away": pivot.shift_away,
            "risk_state": risk.state,
            "risk_pct": risk.risk_pct,
            "reasons": setup.reasons,
        }

    def _write_json(self, path: Path, payload: dict[str, Any]) -> None:
        ensure_runtime_dirs()
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(json.dumps(payload, indent=2, default=_json_default), encoding="utf-8")
        tmp.replace(path)
