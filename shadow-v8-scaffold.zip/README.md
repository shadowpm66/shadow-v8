# Shadow v8

Modular trading engine scaffold.

Phase 1 includes the package structure, typed models, configuration, first-pass structure engines, stage scoring, fundamentals stubs, strategy decisions, research logging, dashboard JSON output, and a dry-run engine loop.

This version is intentionally dry-run first. Live execution adapters are separated behind execution modules so Bybit, IBKR, and future brokers can be connected without mixing execution plumbing into strategy logic.

Phase 2 adds paper execution. Set `SHADOW_EXECUTION_MODE=paper` to let approved v8 decisions create paper positions in `runtime/positions.json`; set it back to `scan_only` to disable that. Crypto live trading defaults to off until the v8 live adapter is wired and tested.

The dashboard shows scanner rankings, setup quality, engine health, risk limits, risk states, tracked paper/live positions, open PnL, and recent decisions.
