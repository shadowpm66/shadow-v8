# Shadow v8

Modular trading engine scaffold.

Phase 1 includes the package structure, typed models, configuration, first-pass structure engines, stage scoring, fundamentals stubs, strategy decisions, and a dry-run main entry point.

This version is intentionally dry-run first. Live execution adapters are separated behind execution modules so Bybit, IBKR, and future brokers can be connected without mixing execution plumbing into strategy logic.
