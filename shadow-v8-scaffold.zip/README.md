# Shadow v8

Modular trading engine scaffold.

Phase 1 includes the package structure, typed models, configuration, first-pass structure engines, stage scoring, fundamentals stubs, strategy decisions, research logging, dashboard JSON output, and a dry-run engine loop.

This version is intentionally dry-run first. Live execution adapters are separated behind execution modules so Bybit, IBKR, and future brokers can be connected without mixing execution plumbing into strategy logic.

The dashboard shows scanner rankings, setup quality, engine health, risk limits, risk states, open position placeholders, and recent decisions. Crypto live trading defaults to off until the v8 execution adapter is wired and tested.
