from __future__ import annotations


class Replay:
    def run(self) -> dict:
        return {"ok": False, "reason": "Replay not implemented yet"}

