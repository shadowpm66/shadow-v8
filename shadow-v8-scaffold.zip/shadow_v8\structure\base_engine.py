from __future__ import annotations

from shadow_v8.models import BaseState, Candle, Direction
from shadow_v8.structure.indicators import atr
from shadow_v8.utils import clamp


class BaseEngine:
    def __init__(
        self,
        min_bars: int = 15,
        max_bars: int = 90,
        max_depth_pct: float = 35.0,
        tight_range_atr_mult: float = 1.25,
    ) -> None:
        self.min_bars = min_bars
        self.max_bars = max_bars
        self.max_depth_pct = max_depth_pct
        self.tight_range_atr_mult = tight_range_atr_mult

    def evaluate(self, candles: list[Candle], direction: Direction = "LONG") -> BaseState:
        if len(candles) < self.min_bars:
            return BaseState(found=False, reasons=["Not enough candles for base detection"])

        window = candles[-self.max_bars :]
        best: BaseState | None = None
        atr_value = atr(candles) or 0.0

        for size in range(self.min_bars, min(len(window), self.max_bars) + 1):
            sample = window[-size:]
            high = max(c.high for c in sample)
            low = min(c.low for c in sample)
            last = sample[-1].close
            if last <= 0 or high <= low:
                continue

            depth_pct = (high - low) / last * 100.0
            if depth_pct > self.max_depth_pct:
                continue

            recent = sample[-min(8, len(sample)) :]
            recent_range = max(c.high for c in recent) - min(c.low for c in recent)
            range_tight = atr_value > 0 and recent_range <= atr_value * self.tight_range_atr_mult
            closes = [c.close for c in recent]
            close_tight_pct = ((max(closes) - min(closes)) / max(last, 1e-9)) * 100.0

            volume_dry = False
            if len(sample) >= 20:
                old_vol = sum(c.volume for c in sample[-20:-10]) / 10
                new_vol = sum(c.volume for c in sample[-10:]) / 10
                volume_dry = new_vol < old_vol * 0.75 if old_vol > 0 else False

            pivot = high if direction == "LONG" else low
            tightness_score = clamp(100.0 - depth_pct * 2.0 - close_tight_pct * 3.0, 0.0, 100.0)
            if range_tight:
                tightness_score += 10.0
            if volume_dry:
                tightness_score += 10.0
            tightness_score = clamp(tightness_score, 0.0, 100.0)

            quality = tightness_score
            if size >= 25:
                quality += 5.0
            if depth_pct <= 20:
                quality += 5.0
            quality = clamp(quality, 0.0, 100.0)

            state = BaseState(
                found=True,
                high=high,
                low=low,
                mid=(high + low) / 2.0,
                pivot=pivot,
                duration_bars=size,
                depth_pct=depth_pct,
                tightness_score=tightness_score,
                volume_dry_up=volume_dry,
                quality_score=quality,
                reasons=[
                    f"Base depth {depth_pct:.1f}%",
                    f"Duration {size} bars",
                    "Recent range tight" if range_tight else "Recent range not tight",
                    "Volume dry-up" if volume_dry else "No volume dry-up",
                ],
            )

            if best is None or state.quality_score > best.quality_score:
                best = state

        return best or BaseState(found=False, reasons=["No valid base found"])

