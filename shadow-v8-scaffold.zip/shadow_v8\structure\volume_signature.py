from __future__ import annotations

from shadow_v8.models import Candle


def has_breakout_volume(candles: list[Candle], lookback: int = 20, multiplier: float = 1.5) -> bool:
    if len(candles) < lookback + 1:
        return False
    avg = sum(c.volume for c in candles[-lookback - 1 : -1]) / lookback
    return candles[-1].volume >= avg * multiplier if avg > 0 else False


def has_volume_dry_up(candles: list[Candle], lookback: int = 20) -> bool:
    if len(candles) < lookback:
        return False
    first = candles[-lookback : -lookback // 2]
    second = candles[-lookback // 2 :]
    old = sum(c.volume for c in first) / len(first)
    new = sum(c.volume for c in second) / len(second)
    return new < old * 0.7 if old > 0 else False

