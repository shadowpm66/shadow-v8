"""Strategy decision modules."""

