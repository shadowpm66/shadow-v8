from __future__ import annotations

from datetime import datetime, timezone
from io import StringIO
from typing import Any

import pandas as pd
import requests

from shadow_v8.data.market_data import MarketDataProvider
from shadow_v8.models import AssetConfig, Candle, MarketDataBundle


class StooqMarketData(MarketDataProvider):
    """Daily/weekly stock OHLCV provider using Stooq's public CSV endpoint."""

    def __init__(self, suffix: str = "us", timeout_sec: float = 10.0) -> None:
        self.suffix = suffix.strip().lower() or "us"
        self.timeout_sec = timeout_sec
        self.base_url = "https://stooq.com/q/d/l/"

    def _stooq_symbol(self, symbol: str) -> str:
        cleaned = symbol.strip().lower().replace("-", ".")
        if "." in cleaned:
            return cleaned
        return f"{cleaned}.{self.suffix}"

    def _fetch_daily_frame(self, symbol: str) -> pd.DataFrame:
        params: dict[str, Any] = {"s": self._stooq_symbol(symbol), "i": "d"}
        response = requests.get(
            self.base_url,
            params=params,
            headers={"User-Agent": "Shadow v8 research"},
            timeout=self.timeout_sec,
        )
        response.raise_for_status()

        text = response.text.strip()
        if not text or text.lower().startswith("no data"):
            return pd.DataFrame()

        frame = pd.read_csv(StringIO(text))
        required = {"Date", "Open", "High", "Low", "Close", "Volume"}
        if not required.issubset(frame.columns):
            return pd.DataFrame()

        frame["Date"] = pd.to_datetime(frame["Date"], utc=True, errors="coerce")
        for col in ("Open", "High", "Low", "Close", "Volume"):
            frame[col] = pd.to_numeric(frame[col], errors="coerce")

        frame = frame.dropna(subset=["Date", "Open", "High", "Low", "Close"])
        frame = frame.sort_values("Date")
        frame = frame[frame["Close"] > 0]
        return frame.tail(650).reset_index(drop=True)

    def _weekly_frame(self, daily: pd.DataFrame) -> pd.DataFrame:
        if daily.empty:
            return pd.DataFrame()

        weekly = (
            daily.set_index("Date")
            .resample("W-FRI")
            .agg(
                {
                    "Open": "first",
                    "High": "max",
                    "Low": "min",
                    "Close": "last",
                    "Volume": "sum",
                }
            )
            .dropna(subset=["Open", "High", "Low", "Close"])
            .reset_index()
        )
        return weekly.tail(220)

    def _to_candles(self, frame: pd.DataFrame) -> list[Candle]:
        candles: list[Candle] = []
        for row in frame.itertuples(index=False):
            timestamp = row.Date.to_pydatetime() if hasattr(row.Date, "to_pydatetime") else row.Date
            if not isinstance(timestamp, datetime):
                timestamp = datetime.now(timezone.utc)
            if timestamp.tzinfo is None:
                timestamp = timestamp.replace(tzinfo=timezone.utc)

            candles.append(
                Candle(
                    timestamp=timestamp,
                    open=float(row.Open),
                    high=float(row.High),
                    low=float(row.Low),
                    close=float(row.Close),
                    volume=float(row.Volume or 0.0),
                )
            )
        return candles

    def load(self, asset: AssetConfig) -> MarketDataBundle:
        daily_frame = self._fetch_daily_frame(asset.symbol)
        metadata = {"source": "stooq", "stooq_symbol": self._stooq_symbol(asset.symbol)}

        if daily_frame.empty:
            metadata["status"] = "empty"
            return MarketDataBundle(
                symbol=asset.symbol,
                asset_class=asset.asset_class,
                metadata=metadata,
            )

        daily = self._to_candles(daily_frame)
        weekly = self._to_candles(self._weekly_frame(daily_frame))
        return MarketDataBundle(
            symbol=asset.symbol,
            asset_class=asset.asset_class,
            candles={"D": daily, "W": weekly},
            last_price=float(daily[-1].close) if daily else None,
            metadata=metadata,
        )
