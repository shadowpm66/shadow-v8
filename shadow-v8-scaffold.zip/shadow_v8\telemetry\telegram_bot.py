from __future__ import annotations

import os

import requests


class TelegramBot:
    def __init__(self) -> None:
        self.token = os.getenv("TELEGRAM_BOT_TOKEN", "")
        self.chat_id = os.getenv("TELEGRAM_CHAT_ID", "")

    def send(self, message: str) -> bool:
        if not self.token or not self.chat_id:
            print(message)
            return False
        try:
            url = f"https://api.telegram.org/bot{self.token}/sendMessage"
            for chunk in self._chunks(message):
                response = requests.post(url, data={"chat_id": self.chat_id, "text": chunk}, timeout=10)
                response.raise_for_status()
            return True
        except Exception as exc:
            print(f"Telegram send failed: {exc}")
            return False

    def _chunks(self, message: str, size: int = 3900) -> list[str]:
        if len(message) <= size:
            return [message]
        return [message[i : i + size] for i in range(0, len(message), size)]
