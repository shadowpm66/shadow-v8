from __future__ import annotations

from shadow_v8.models import FundamentalState


class GrowthEngine:
    def evaluate(self, revenue: list[float], eps: list[float]) -> FundamentalState:
        revenue_growth = self._growth_series(revenue)
        eps_growth = self._growth_series(eps)
        rev_accel = self._accelerating(revenue_growth)
        eps_accel = self._accelerating(eps_growth)
        grade = "UNKNOWN"
        if rev_accel and eps_accel and (revenue_growth[-1:] or [0])[0] >= 20:
            grade = "A"
        elif rev_accel or eps_accel:
            grade = "B"
        elif revenue_growth or eps_growth:
            grade = "C"
        return FundamentalState(
            revenue_growth_yoy=revenue_growth,
            eps_growth_yoy=eps_growth,
            revenue_accelerating=rev_accel,
            eps_accelerating=eps_accel,
            fundamental_grade=grade,
            reasons=[
                "Revenue accelerating" if rev_accel else "Revenue not accelerating",
                "EPS accelerating" if eps_accel else "EPS not accelerating",
            ],
        )

    def _growth_series(self, values: list[float]) -> list[float]:
        if len(values) < 5:
            return []
        growth: list[float] = []
        for idx in range(4, len(values)):
            old = values[idx - 4]
            new = values[idx]
            growth.append(((new - old) / abs(old)) * 100.0 if old else 0.0)
        return growth

    def _accelerating(self, growth: list[float]) -> bool:
        if len(growth) < 3:
            return False
        return growth[-1] > growth[-2] > growth[-3]

