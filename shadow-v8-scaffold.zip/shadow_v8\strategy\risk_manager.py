from __future__ import annotations

from shadow_v8.models import AssetConfig, RiskDecision, SetupDecision


class RiskManager:
    def evaluate(self, asset: AssetConfig, setup: SetupDecision) -> RiskDecision:
        if setup.grade == "REJECT":
            return RiskDecision(state="OFF", risk_pct=0.0, reason="Rejected setup")
        if setup.grade in ("S", "A+"):
            return RiskDecision(state="FULL", risk_pct=asset.max_risk_pct, reason="High-grade setup")
        if setup.grade == "A":
            return RiskDecision(state="REDUCED", risk_pct=asset.max_risk_pct * 0.75, reason="A setup")
        if setup.grade == "B":
            return RiskDecision(state="DEFENSIVE", risk_pct=asset.max_risk_pct * 0.35, reason="B setup")
        return RiskDecision(state="OFF", risk_pct=0.0, reason="Low-grade setup")

