from __future__ import annotations

from shadow_v8.models import AssetConfig, ScannerConfig


class StockScanner:
    """Scanner interface.

    Later this can use IBKR scanner, SEC universe filters, or a market data API.
    """

    def scan(self, config: ScannerConfig) -> list[AssetConfig]:
        return []

