from __future__ import annotations

from shadow_v8.models import AssetConfig, ScannerConfig
from shadow_v8.data.bybit_market_data import BybitMarketData


class StockScanner:
    """Scanner interface.

    Later this can use IBKR scanner, SEC universe filters, or a market data API.
    """

    def scan(self, config: ScannerConfig) -> list[AssetConfig]:
        return []


class CryptoScanner:
    def __init__(self, bybit: BybitMarketData | None = None) -> None:
        self.bybit = bybit or BybitMarketData()

    def scan(self, config: dict) -> list[AssetConfig]:
        if not config.get("enabled", True):
            return []
        max_symbols = int(config.get("max_symbols") or 25)
        if config.get("scan_all_usdt", False):
            symbols = self.bybit.list_linear_usdt_symbols(max_symbols=max_symbols)
        else:
            symbols = list(config.get("seed_symbols") or [])
        symbols = [s.strip().upper() for s in symbols if s and s.strip()]
        symbols = list(dict.fromkeys(symbols))[:max_symbols]
        return [
            AssetConfig(
                symbol=symbol,
                asset_class="crypto",
                broker="bybit",
                enabled=True,
                primary_timeframe="D",
                confirmation_timeframe="W",
                intraday_timeframes=(),
                allow_long=True,
                allow_short=True,
                fundamentals_required=False,
                max_risk_pct=0.01,
                tags=("crypto_scan",),
            )
            for symbol in symbols
        ]
