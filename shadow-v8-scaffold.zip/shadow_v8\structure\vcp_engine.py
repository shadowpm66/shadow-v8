from __future__ import annotations

from shadow_v8.models import Candle, VcpState
from shadow_v8.structure.indicators import atr
from shadow_v8.utils import clamp


class VcpEngine:
    def evaluate(self, candles: list[Candle], lookback: int = 60, pivot: float | None = None) -> VcpState:
        if len(candles) < 30:
            return VcpState(reasons=["Not enough candles for VCP"])
        sample = candles[-lookback:]
        chunks = self._chunks(sample, 4)
        ranges = [max(c.high for c in chunk) - min(c.low for c in chunk) for chunk in chunks if chunk]
        contraction_count = 0
        for prev, cur in zip(ranges, ranges[1:]):
            if cur < prev:
                contraction_count += 1
        vols = [sum(c.volume for c in chunk) / len(chunk) for chunk in chunks if chunk]
        volume_dry = len(vols) >= 2 and vols[-1] < vols[0] * 0.7
        lows = [min(c.low for c in chunk) for chunk in chunks if chunk]
        highs = [max(c.high for c in chunk) for chunk in chunks if chunk]
        higher_lows = len(lows) >= 3 and lows[-1] >= lows[-2] >= lows[-3]
        lower_highs = len(highs) >= 3 and highs[-1] <= highs[-2] <= highs[-3]
        last = sample[-1].close
        atr_value = atr(candles) or 0.0
        last_range = ranges[-1] if ranges else 0.0
        prior_range = ranges[0] if ranges else 0.0
        range_contracted_pct = (1.0 - last_range / prior_range) * 100.0 if prior_range > 0 else 0.0
        near_pivot = False
        stop_quality = "UNKNOWN"
        if pivot:
            stop_distance_pct = abs(last - pivot) / max(last, 1e-9) * 100.0
            near_pivot = stop_distance_pct <= 5.0
        elif atr_value > 0 and last > 0:
            stop_distance_pct = (last_range / last) * 100.0
        else:
            stop_distance_pct = None
        if stop_distance_pct is not None:
            if stop_distance_pct <= 3.0:
                stop_quality = "GOOD"
            elif stop_distance_pct <= 6.0:
                stop_quality = "ACCEPTABLE"
            else:
                stop_quality = "WIDE"

        score = contraction_count * 16.0
        score += 18.0 if volume_dry else 0.0
        score += 12.0 if higher_lows else 0.0
        score += 8.0 if lower_highs else 0.0
        score += 10.0 if range_contracted_pct >= 35.0 else 0.0
        score += 8.0 if near_pivot else 0.0
        score += 8.0 if stop_quality == "GOOD" else 4.0 if stop_quality == "ACCEPTABLE" else -8.0 if stop_quality == "WIDE" else 0.0
        score = clamp(score, 0.0, 100.0)
        return VcpState(
            is_tight=score >= 60.0,
            tightness_score=score,
            contraction_count=contraction_count,
            volume_dry=volume_dry,
            higher_lows=higher_lows,
            lower_highs=lower_highs,
            stop_distance_quality=stop_quality,
            reasons=[
                f"{contraction_count} range contractions",
                "Volume dry-up" if volume_dry else "Volume not dry",
                "Higher lows" if higher_lows else "Higher lows not confirmed",
                f"Range contracted {range_contracted_pct:.1f}%",
                f"Stop distance quality {stop_quality}",
            ],
            metadata={
                "ranges": [round(r, 4) for r in ranges],
                "average_volumes": [round(v, 2) for v in vols],
                "range_contracted_pct": round(range_contracted_pct, 2),
                "near_pivot": near_pivot,
                "stop_distance_pct": round(stop_distance_pct, 3) if stop_distance_pct is not None else None,
                "atr": round(atr_value, 4) if atr_value else None,
            },
        )

    def _chunks(self, values: list[Candle], count: int) -> list[list[Candle]]:
        size = max(1, len(values) // count)
        return [values[i : i + size] for i in range(0, len(values), size)][-count:]
