from __future__ import annotations

from shadow_v8.models import Candle, VcpState
from shadow_v8.utils import clamp


class VcpEngine:
    def evaluate(self, candles: list[Candle], lookback: int = 50) -> VcpState:
        if len(candles) < 30:
            return VcpState(reasons=["Not enough candles for VCP"])
        sample = candles[-lookback:]
        chunks = self._chunks(sample, 4)
        ranges = [max(c.high for c in chunk) - min(c.low for c in chunk) for chunk in chunks if chunk]
        contraction_count = 0
        for prev, cur in zip(ranges, ranges[1:]):
            if cur < prev:
                contraction_count += 1
        vols = [sum(c.volume for c in chunk) / len(chunk) for chunk in chunks if chunk]
        volume_dry = len(vols) >= 2 and vols[-1] < vols[0] * 0.7
        lows = [min(c.low for c in chunk) for chunk in chunks if chunk]
        highs = [max(c.high for c in chunk) for chunk in chunks if chunk]
        higher_lows = len(lows) >= 2 and lows[-1] >= min(lows[:-1])
        lower_highs = len(highs) >= 2 and highs[-1] <= max(highs[:-1])
        score = contraction_count * 18.0
        score += 18.0 if volume_dry else 0.0
        score += 12.0 if higher_lows else 0.0
        score += 8.0 if lower_highs else 0.0
        score = clamp(score, 0.0, 100.0)
        return VcpState(
            is_tight=score >= 60.0,
            tightness_score=score,
            contraction_count=contraction_count,
            volume_dry=volume_dry,
            higher_lows=higher_lows,
            lower_highs=lower_highs,
            stop_distance_quality="UNKNOWN",
            reasons=[
                f"{contraction_count} range contractions",
                "Volume dry-up" if volume_dry else "Volume not dry",
                "Higher lows" if higher_lows else "Higher lows not confirmed",
            ],
        )

    def _chunks(self, values: list[Candle], count: int) -> list[list[Candle]]:
        size = max(1, len(values) // count)
        return [values[i : i + size] for i in range(0, len(values), size)][-count:]

