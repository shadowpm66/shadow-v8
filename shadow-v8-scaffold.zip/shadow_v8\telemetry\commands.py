from __future__ import annotations


class CommandProcessor:
    def process_once(self) -> dict:
        return {"ok": True, "commands": 0}

